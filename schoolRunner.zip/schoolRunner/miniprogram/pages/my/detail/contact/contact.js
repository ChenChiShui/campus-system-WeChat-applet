
Page({
  data: {
    List:[
      {
        title:"开发者",
        value:"陈驰水"
      },
      {
        title:"联系方式",
        value:"18810690950"
      },
      {
        title:"微信号",
        value:"walter_chencs"
      },
      {
        title:"开发版本",
        value:"V0.0.2"
      },
    ]
  },
  onLoad: function () {

  },
})